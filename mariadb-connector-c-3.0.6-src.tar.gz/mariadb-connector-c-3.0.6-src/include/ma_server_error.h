/* This file exists for compatibility only */
#include "mysqld_error.h"
